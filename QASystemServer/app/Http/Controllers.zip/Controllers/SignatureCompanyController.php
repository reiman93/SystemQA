<?php

namespace App\Http\Controllers;

use App\Models\Signature_company;
use Illuminate\Http\Request;

class SignatureCompanyController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Signature_company  $signature_company
     * @return \Illuminate\Http\Response
     */
    public function show(Signature_company $signature_company)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Signature_company  $signature_company
     * @return \Illuminate\Http\Response
     */
    public function edit(Signature_company $signature_company)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Signature_company  $signature_company
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Signature_company $signature_company)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Signature_company  $signature_company
     * @return \Illuminate\Http\Response
     */
    public function destroy(Signature_company $signature_company)
    {
        //
    }
}
